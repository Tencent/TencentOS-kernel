/*
 * Copyright(c) 2017 Broadcom Corporation, all rights reserved
 * Proprietary and Confidential Information.
 *
 * This source file is the property of Broadcom Corporation, and
 * may not be copied or distributed in any isomorphic form without
 * the prior written consent of Broadcom Corporation.
 */

#ifndef _DECODE_HSI_H_
#define _DECODE_HSI_H_

#include "decode_template_linux.h"

// toplevel decode functions

const char * decode_type(__le32 data);
const char * decode_req_type(__le32 data);
const char * decode_error_code(__le32 data);
const char * decode_cmd_err(__le16 req_type, u8 cmd_err_code);

int decode_err_output(const void * data);
int decode_hwrm_req(const void * data);
int decode_hwrm_resp(const void * data);
int decode_hwrm_async_event(const void * data);

// define expand macro to produce decode function prototypes
// from templates

#define PROTO_INT(s, S) int decode_##s(const void *data);
T_ASYNC_LIST(PROTO_INT);
T_OTHER_LIST(PROTO_INT);

// define expand macro to produce decode function prototypes
// for error structures from templates

#define PROTO_CHAR(s, S) const char * decode_##s(__le32 data);
T_ERR_LIST(PROTO_CHAR);

#endif /* _DECODE_HSI_H_ */
