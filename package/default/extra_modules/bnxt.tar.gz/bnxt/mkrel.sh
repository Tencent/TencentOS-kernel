#! /usr/bin/bsh

if [ $# -eq 0 ]; then
	nseg_path=/mnt/nseg
else
	nseg_path=$1
fi

bnxt_ver=$(grep "define DRV_MODULE_VERSION" bnxt.h | cut -f 2 | sed 's/"//g')
make clean
mkdir bnxt_en-${bnxt_ver}
cp b*.[ch] Makefile RELEASE.TXT README.TXT COPYING ChangeLog bnxt_en-${bnxt_ver}/
rm -f bnxt_en-${bnxt_ver}/bnxt_re*
rm -f bnxt_en-${bnxt_ver}/decode*
rm -f bnxt_en-${bnxt_ver}/bcm*.h
tar cvzf bnxt_en-${bnxt_ver}.tar.gz bnxt_en-${bnxt_ver}
mkdir ${nseg_path}/rels/bcm5734x/drivers/linux/${bnxt_ver}
cp bnxt_en-${bnxt_ver}.tar.gz ${nseg_path}/rels/bcm5734x/drivers/linux/${bnxt_ver}
rm -rf bnxt_en-${bnxt_ver}
cp RELEASE.TXT ${nseg_path}/rels/bcm5734x/drivers/linux/${bnxt_ver}
cp ChangeLog ${nseg_path}/rels/bcm5734x/drivers/linux/${bnxt_ver}
