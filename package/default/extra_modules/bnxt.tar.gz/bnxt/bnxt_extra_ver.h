/* Broadcom NetXtreme-C/E network driver.
 *
 * Copyright (c) 2016-2017 Broadcom Limited
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 */

#ifndef BNXT_EXTRA_VER_H
#define BNXT_EXTRA_VER_H

#define DRV_MODULE_EXTRA_VER  "-214.1.58.0"

#endif
