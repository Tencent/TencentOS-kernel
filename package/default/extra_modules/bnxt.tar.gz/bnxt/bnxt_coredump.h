/* Broadcom NetXtreme-C/E network driver.
 *
 * Copyright (c) 2018 Broadcom Inc
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 */

#ifndef BNXT_COREDUMP_H
#define BNXT_COREDUMP_H

#if defined(ETHTOOL_GET_DUMP_FLAG) && !defined(GET_ETHTOOL_OP_EXT)
struct bnxt_coredump_segment_hdr {
	__u8 signature[4];
	__u32 component_id;
	__u32 segment_id;
	__u32 flags;
	__u8 low_version;
	__u8 high_version;
	__u16 function_id;
	__u32 offset;
	__u32 length;
	__u32 status;
	__u32 duration;
	__u32 data_offset;
	__u32 instance;
	__u32 rsvd[5];
};

struct bnxt_coredump_record {
	__u8 signature[4];
	__u32 flags;
	__u8 low_version;
	__u8 high_version;
	__u8 asic_state;
	__u8 rsvd0[5];
	char system_name[32];
	__u16 year;
	__u16 month;
	__u16 day;
	__u16 hour;
	__u16 minute;
	__u16 second;
	__s16 utc_bias;
	__u16 rsvd1;
	char commandline[256];
	__u32 total_segments;
	__u32 os_ver_major;
	__u32 os_ver_minor;
	__u32 rsvd2;
	char os_name[32];
	__u16 end_year;
	__u16 end_month;
	__u16 end_day;
	__u16 end_hour;
	__u16 end_minute;
	__u16 end_second;
	__s16 end_utc_bias;
	__u32 asic_id1;
	__u32 asic_id2;
	__s32 coredump_status;
	__u8 ioctl_low_version;
	__u8 ioctl_high_version;
	__u16 rsvd3[313];
};
#endif /* defined(ETHTOOL_GET_DUMP_FLAG) && !defined(GET_ETHTOOL_OP_EXT) */
#endif
