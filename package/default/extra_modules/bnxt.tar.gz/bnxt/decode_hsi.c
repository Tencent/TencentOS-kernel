/****************************************************************************
 * Copyright(c) 2001-2017 Broadcom Corporation, all rights reserved
 * Proprietary and Confidential Information.
 *
 * This source file is the property of Broadcom Corporation, and
 * may not be copied or distributed in any isomorphic form without
 * the prior written consent of Broadcom Corporation.
 *
 * Name:  decode_hsi.c
 *
 * Description: HSI data structures decoding helper functions
 ****************************************************************************/
#ifdef HSI_OUTPUT
// nothing, all is already set up
#elif defined __KERNEL__
#include <linux/types.h>
#include <linux/kernel.h>
#include <asm/types.h>
#define HSI_OUTPUT printk
#define PRINT_PARAM1 KERN_ERR
#elif defined(NDIS_MINIPORT_DRIVER)
#include <ndis.h>
#define HSI_OUTPUT DbgPrintEx
#define PRINT_PARAM1 DPFLTR_IHVNETWORK_ID, DPFLTR_ERROR_LEVEL,
#elif defined(ESX_GDB)
#include <Python.h>
#define HSI_OUTPUT printf
#define PRINT_PARAM1
#elif defined(EFI_DRIVER)
#include <Library/UefiLib.h>
#define HSI_OUTPUT AsciiPrint
#define PRINT_PARAM1
#else
#include <tcl.h>
#include <stddef.h>
#define HSI_OUTPUT printf
#define PRINT_PARAM1
#endif
#include "bcmtype.h"
#if defined __KERNEL__
#include "bnxt_hsi.h"
#else
#include "hsi_struct_def.h"
#endif
#ifndef HSI_DBG_DISABLE
#include "decode_hsi.h"

/* macros for various ways to expand structure lists */
#define STATIC_PROTO(s, S) static int decode_##s(const void *data);
#define NAME_STR(s, S) case S: return #S;
#define ERR_DECODE(s, S) case S: return decode_##s(cmd_err_code);
#define DATA_DECODE(s, S) case S: return decode_##s(data);

/* print_structure prototype */

enum s_type {
    t_input,
    t_output,
    t_error,
    t_other
};

static int print_structure(const void *data, entry_template_t *tmpl,
                           enum s_type stype);

/* Decode enum value name from enum template */

static const char * decode_enum(__le32 data, entry_template_t *entry) {
    while (entry->type != STRUCT_END) {
        if ((entry->type == ENUM_VAL) &&
            (data == entry->u.ev.value ))
            return entry->name;
        entry++;
    }
    return "Undefined code point";
}

/* Decode buffer descriptor type */

const char * decode_type(__le32 data) {
    entry_template_t tmpl[] = template_bd_base;
    return decode_enum(data, tmpl);
}

/* Decode hwrm request type */

const char * decode_req_type(__le32 data) {
    /* Expand input structures in switch statement */

    switch (data) {
        T_INPUT_LIST(NAME_STR);
    }

    return "Undefined req_type";
}

/* Decode hwrm error */

const char * decode_error_code(__le32 data) {
    entry_template_t tmpl[] = template_ret_codes;
    return decode_enum(data, tmpl);
}

/* Decode hwrm command specific error */

const char * decode_cmd_err(__le16 req_type, u8 cmd_err_code)  {
    /* Expand error structures in switch statement */

    switch (req_type) {
        T_ERR_LIST(ERR_DECODE);
    }

    return "Undefined CmdErr";
}

/* Decode error hwrm response structure */

int decode_err_output(const void * data) {
    static entry_template_t tmpl[] = template_hwrm_err_output;
    return print_structure(data, tmpl, t_error);
}

/* Expand prototypes for static decode input functions */

T_INPUT_LIST(STATIC_PROTO);

/* Decode hwrm input structures */

int decode_hwrm_req(const void *data)  {
    /* Expand input structures in switch statement */

    const struct input *hdr = (struct input *)data;

    switch (hdr->req_type) {
        T_INPUT_LIST(DATA_DECODE);
    }

    HSI_OUTPUT(PRINT_PARAM1 "Invalid req_type 0x%x", hdr->req_type);
    return 1;
}

/* Expand protoytpes for static decode output functions */

T_OUTPUT_LIST(STATIC_PROTO);

/* Decode hwrm output structures */

int decode_hwrm_resp(const void *data)  {
    /* Expand output structures in switch statement */

    const struct output *hdr = (struct output *)data;

    switch (hdr->req_type) {
        T_OUTPUT_LIST(DATA_DECODE);
    }

    HSI_OUTPUT(PRINT_PARAM1 "Invalid req_type 0x%x", hdr->req_type);
    return 1;
}

/* Decode hwrm async event structures */

#if defined __KERNEL__
#define ASYNC_DECODE(s, S) case S: return decode_##s(data);
#else
#define ASYNC_DECODE(s, S) case HWRM_##S: return decode_##s(data);
#endif

int decode_hwrm_async_event(const void * data) {
    /* Expand async structures in switch statement */

    const struct hwrm_async_event_cmpl *hdr = (struct hwrm_async_event_cmpl *)data;

    switch (hdr->event_id) {
        T_ASYNC_LIST(ASYNC_DECODE);
    }

    HSI_OUTPUT(PRINT_PARAM1 "Invalid event id 0x%x", hdr->event_id);
    return 1;

}

/* Generic decode implementation,
   prints decoded structures from template definitions */

#define DECODE_BUFFER_SIZE   512
#define DECODE_BUFFER_THRESH 384

struct decode_buffer {
    __le32 size;
    __le16 lines;
    __le16 max;
    char str[DECODE_BUFFER_SIZE];
};

static void buffer_init(struct decode_buffer *buf) {
    buf->size = 0;
    buf->lines = 0;
    buf->str[0] = 0;
}

#define buffer_cat(buf, ...)                                  \
    {                                                         \
        (buf)->size += snprintf(&((buf)->str[(buf)->size]),         \
                                DECODE_BUFFER_SIZE - (buf)->size,   \
                                __VA_ARGS__);                       \
        buffer_flush_helper(buf, 0);                                \
    }

static int buffer_flush_helper(struct decode_buffer *buf,
                               int force) {
    int i = 0;

    if ((buf->size == 0) ||
        (!force && (buf->size < DECODE_BUFFER_THRESH)) ||
        (buf->str[buf->size-1] != '\n'))
        return buf->lines;

    if (buf->size >= DECODE_BUFFER_SIZE) {
        buf->size = DECODE_BUFFER_SIZE - 20;
        buffer_cat(buf, " <truncated>\n");
    }

    while ((i < DECODE_BUFFER_SIZE) && (buf->str[i++] != 0)) {
        if (buf->str[i] == '\n')
            buf->lines++;
    }

    HSI_OUTPUT(PRINT_PARAM1 "%s", buf->str);

    buf->size = 0;
    buf->str[0] = 0;

    return buf->lines;
}

static int buffer_flush(struct decode_buffer *buf) {
    return (buffer_flush_helper(buf, 1));
}

/* Table of formats for hex value, indexed by number of nibbles */

static const char *hex_fmt[] = {
    "0x%01jx",  "0x%01jx",  "0x%02jx",  "0x%03jx",
    "0x%04jx",  "0x%05jx",  "0x%06jx",  "0x%07jx",
    "0x%08jx",  "0x%09jx",  "0x%010jx", "0x%011jx",
    "0x%012jx", "0x%013jx", "0x%014jx", "0x%015jx",
    "0x%016jx"
};

/* Extract a structure value from specified offset in data */

#define GET_UVAL(dp,ofs,w) (*(u##w##_t *)&((u8 *)dp)[ofs])
static __le64 get_val(const void *data, __le16 offset, data_type_t type)
{
    switch (type) {
    case DT_UINT64:
    case DT_INT64:
        return GET_UVAL(data, offset, 64);
    case DT_UINT32:
    case DT_INT32:
        return GET_UVAL(data, offset, 32);
    case DT_UINT16:
    case DT_INT16:
        return GET_UVAL(data, offset, 16);
    case DT_CHAR:
    case DT_UINT8:
    case DT_INT8:
        return GET_UVAL(data, offset, 8);
    default:
        break;
    }
    return 0ULL;
}

/* Print a structure field */

static void print_field(struct decode_buffer *buf, const void *data,
                        entry_template_t **tmpl, enum s_type stype)
{
    int nibbles;
    entry_template_t *entry = *tmpl;
    const struct input *in_hdr = (struct input *)data;
    const struct output *out_hdr = (struct output *)data;
    const struct hwrm_err_output *err_hdr = (struct hwrm_err_output *)data;

    __le64 val = get_val(data, entry->offset_bytes,
                         entry->u.f.data_type);

    buffer_cat(buf, "%04x: %-40s: ", entry->offset_bytes,
               entry->name);

    nibbles =  (entry->size_bits + 3) / 4;
    buffer_cat(buf, hex_fmt[nibbles], (__le64)val);

    /* Check to see if this field requires special field decoding */

    switch (stype) {
    case t_input:
        if (entry->offset_bytes == offsetof(struct input, req_type))
            buffer_cat(buf, " (%s)", decode_req_type(in_hdr->req_type));
        break;

    case t_output:
        if (entry->offset_bytes == offsetof(struct output, error_code))
            buffer_cat(buf, " (%s)", decode_error_code(out_hdr->error_code));
        if (entry->offset_bytes == offsetof(struct output, req_type))
            buffer_cat(buf, " (%s)", decode_req_type(out_hdr->req_type));
        break;

    case t_error:
        if (entry->offset_bytes ==
            offsetof(struct hwrm_err_output, error_code))
            buffer_cat(buf, " (%s)", decode_error_code(err_hdr->error_code));
        if (entry->offset_bytes ==
            offsetof(struct hwrm_err_output, req_type))
            buffer_cat(buf, " (%s)", decode_req_type(err_hdr->req_type));
        if (entry->offset_bytes ==
            offsetof(struct hwrm_err_output, cmd_err))
            buffer_cat(buf, " (%s)",
                       decode_cmd_err(err_hdr->req_type,
                                      err_hdr->cmd_err));
        break;

    case t_other:
        break;
    }

    buffer_cat(buf, "\n");
    *tmpl = ++entry;
}

/* completely consume (print) a bitfield and move to next template entry */

static void print_bitfield(struct decode_buffer *buf, const void *data,
                           entry_template_t **tmpl)
{
    char name[40];
    int nibbles;
    entry_template_t *entry = *tmpl;
    __le64 val = get_val(data, entry->offset_bytes,
                         entry->u.bf.data_type);

    val = (val >> entry->u.bf.bit_offset) &
        ((1ULL << entry->u.bf.num_bits) - 1);

    snprintf(name, 40, "%s[%d:%d]", entry->name,
             entry->u.bf.bit_offset,
             entry->u.bf.bit_offset + entry->u.bf.num_bits - 1);

    buffer_cat(buf, "%04x:   %-38s: ", entry->offset_bytes, name);

    nibbles = (entry->u.bf.num_bits + 3)/4;
    buffer_cat(buf, hex_fmt[nibbles], (__le64)val);
    buffer_cat(buf, "\n");

    *tmpl = ++entry;
}

/* completely consume (print) an enum and move to next template entry */

static void print_enum(struct decode_buffer *buf, const void *data,
                       entry_template_t **tmpl)
{
    entry_template_t *entry = *tmpl;
    __le64 val = get_val(data, entry->offset_bytes,
                         entry->u.e.data_type);

    char name[40];
    int nibbles;
    int found = 0;

    if (entry->u.e.num_bits) {
        val = (val >> entry->u.e.bit_offset) &
            ((1ULL << entry->u.e.num_bits) - 1);

        snprintf(name, 40, "%s[%d:%d]", entry->name,
                 entry->u.e.bit_offset,
                 entry->u.e.bit_offset + entry->u.e.num_bits - 1);

        buffer_cat(buf, "%04x:   %-38s: ", entry->offset_bytes, name);

        nibbles = (entry->u.e.num_bits + 3)/4;
    } else {
        buffer_cat(buf, "%04x: %-40s: ", entry->offset_bytes,
                   entry->name);

        nibbles = (entry->size_bits + 3) / 4;
    }

    buffer_cat(buf, hex_fmt[nibbles], (__le64)val);
    entry++;
    while (entry->type != ENUM_END) {
        if (!found && (val == (__le64)entry->u.ev.value)) {
            buffer_cat(buf, " (%s)", entry->name);
            found = 1;
        }
        entry++;
    }

    if (!found)
        buffer_cat(buf, "(?)");

    buffer_cat(buf, "\n");

    *tmpl = ++entry;
}

/* returns character if character is printable, otherwise returns '.' */

static char mapchar(char c) {
    static int init = 0;
    static u8 map[256];

    int i;
    char printable[] = "!\"#$%&'()*+,-./0123456789:;"
        "<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";

    if (!init) {
        for (i=0; i<256; i++)
            map[i] = 0;

        i = 0;
        while (printable[i])
            map[(int)printable[i++]] = 1;

        init = 1;
    }

    if (map[(int)c])
        return c;

    return '.';
}

/*  completely consume (print) an array and move to next template entry */

static void print_array(struct decode_buffer *buf, const void *data,
                        entry_template_t **tmpl)
{
    entry_template_t *entry = *tmpl;
    __le32 offset = entry->offset_bytes;
    const void *ap = &((u8 *)data)[offset];
    int i, j;

    char name[40];
    snprintf(name, 40, "%s[%d]", entry->name, entry->u.a.count);

    switch (entry->u.a.data_type) {
    case DT_UINT64:
        {
            const __le64 *dp = (__le64 *)ap;
            const __le32 *dp32 = (__le32 *)dp;

            buffer_cat(buf, "%04x: %-40s:", offset, name);
            for (i = 0; i < entry->u.a.count; i++) {
                // 2 values per line
                if (i && !(i % 2)) {
                    buffer_cat(buf, "\n");
                    buffer_cat(buf, "%04x: %-40s:", offset, "");
                }
                buffer_cat(buf, "%s%08x%08x ", !(i % 1) ? " " : "", dp32[1], dp32[0]);
                offset += sizeof(*dp);
                dp++;
            }
            buffer_cat(buf, "\n");

            break;
        }
    case DT_UINT32:
        {
            const __le32 *dp = (__le32 *)ap;

            buffer_cat(buf, "%04x: %-40s:", offset, name);
            for (i = 0; i < entry->u.a.count; i++) {
                // 4 values per line
                if (i && !(i % 4)) {
                    buffer_cat(buf, "\n");
                    buffer_cat(buf, "%04x: %-40s:", offset, "");
                }
                buffer_cat(buf, "%s%08x ", !(i % 2) ? " " : "", *dp++);
                offset += sizeof(*dp);
            }
            buffer_cat(buf, "\n");

            break;
        }
    case DT_UINT16:
        {
            const __le16 *dp = (__le16 *)ap;

            buffer_cat(buf, "%04x: %-40s:", offset, name);
            for (i = 0; i < entry->u.a.count; i++) {
                // 8 values per line
                if (i && !(i % 8)) {
                    buffer_cat(buf, "\n");
                    buffer_cat(buf, "%04x: %-40s:", offset, "");
                }
                buffer_cat(buf, "%s%04x ", !(i % 4) ? " " : "", *dp++);
                offset += sizeof(*dp);
            }
            buffer_cat(buf, "\n");

            break;
        }
    case DT_CHAR:
        {
            const u8 *dp = (u8 *)ap;
            const char *cp = ap;
            int count = entry->u.a.count;

            buffer_cat(buf, "%04x: %-40s:", offset, name);
            for (i = 0, j = 0; i < count; i++) {
                // 16 values per line
                if (i && !(i % 16)) {
                    for (; j < (j % 16); j++) {
                        buffer_cat(buf, "%c", mapchar(*cp));
                        cp++;
                    }
                    buffer_cat(buf, "\n");
                    buffer_cat(buf, "%04x: %-40s:", offset, "");
                }
                buffer_cat(buf, "%s%02x ", !(i % 8) ? " " : "", *dp++);
                offset += sizeof(*dp);
            }
            for (; j < count; j++) {
                buffer_cat(buf, "%c", mapchar(*cp));
                cp++;
            }
            buffer_cat(buf, "\n");

            break;
        }
    case DT_INT8:
    case DT_UINT8:
        {
            const u8 *dp = (u8 *)ap;

            buffer_cat(buf, "%04x: %-40s:", offset, name);
            for (i = 0; i < entry->u.a.count; i++) {
                // 16 values per line
                if (i && !(i % 16)) {
                    buffer_cat(buf, "\n");
                    buffer_cat(buf, "%04x: %-40s:", offset, "");
                }
                buffer_cat(buf, "%s%02x ", !(i % 8) ? " " : "", *dp++);
                offset += sizeof(*dp);
            }
            buffer_cat(buf, "\n");

            break;
        }
    default:
        buffer_cat(buf, "%04x: %-40s: Unsupported type %u\n", offset,
                   name, entry->u.a.data_type);
    }
    *tmpl = ++entry;
}

/* main function to print a structure based on the structure's template */

static int print_structure(const void *data, entry_template_t *tmpl,
                           enum s_type stype)
{
    entry_template_t *entry = tmpl;
    struct decode_buffer buf;

    /* Check for errored response */

    const struct output *hdr = (struct output *)data;
    if ((stype == t_output) && (hdr->error_code))
        return(decode_err_output(data));

    /* Loop over structure entries and print */

    buffer_init(&buf);
    while (entry->type != STRUCT_END) {
        switch (entry->type) {
        case STRUCT_START:
            buffer_cat(&buf, "%s: (%dB)\n", entry->name, entry->u.s.size);
            entry++;
            break;
        case FIELD:
            print_field(&buf, data, &entry, stype);
            break;
        case BITFIELD:
            print_bitfield(&buf, data, &entry);
            break;
        case ENUM:
            print_enum(&buf, data, &entry);
            break;
        case ARRAY:
            print_array(&buf, data, &entry);
            break;
        default:
            buffer_cat(&buf, "decode type %u not supported\n", entry->type);
            entry++;
            break;
        }
    }
    buffer_cat(&buf, "\n");
    return (buffer_flush(&buf));
}

/* Structure decode implementations - macro generated */
/* Expand static decode input functions */

#define DECODE_INPUT_FN(s, S)                           \
static int decode_##s(const void *data)                 \
{                                                       \
    static entry_template_t tmpl[] = template_##s;  \
    return print_structure(data, tmpl, t_input);    \
}
T_INPUT_LIST(DECODE_INPUT_FN);

/* Expand static decode output functions */

#define DECODE_OUTPUT_FN(s, S)                          \
static int decode_##s(const void *data)                 \
{                                                       \
    static entry_template_t tmpl[] = template_##s;  \
    return print_structure(data, tmpl, t_output);   \
}
T_OUTPUT_LIST(DECODE_OUTPUT_FN);

/* Expand decode async and other functions */

#define DECODE_OTHER(s, S)                              \
int decode_##s(const void *data)                        \
{                                                       \
    static entry_template_t tmpl[] = template_##s;  \
    return print_structure(data, tmpl, t_other);    \
}
T_ASYNC_LIST(DECODE_OTHER);
T_OTHER_LIST(DECODE_OTHER);


/* Expand decode error functions */

#define DECODE_ERROR(s, S)                              \
const char * decode_##s(__le32 data)                    \
{                                                       \
    static entry_template_t tmpl[] = template_##s;  \
    return decode_enum(data, tmpl);                 \
}
T_ERR_LIST(DECODE_ERROR);

#else /* defined (HSI_DBG_DISABLE) */

const char * decode_type(__le32 data) {return 0;}
const char * decode_req_type(__le32 data) {return 0;}
const char * decode_error_code(__le32 data) {return 0;}
const char * decode_cmd_err(__le16 req_type, u8 cmd_err_code) {return 0;}
int decode_err_output(const void * data) {return 0;}
int decode_hwrm_req(const void * data) {return 0;}
int decode_hwrm_resp(const void * data) {return 0;}
int decode_hwrm_async_event(const void * data) {return 0;}

/* define expand macros to produce dummy implementations */

#define EMPTY_FN(s, S) int decode_##s(const void *data) {return 0;}
T_ASYNC_LIST(EMPTY_FN);
T_OTHER_LIST(EMPTY_FN);

#define EMPTY_ERR_FN(s, S) const char * decode_##s(__le32 data) {return 0;}
T_ERR_LIST(EMPTY_ERR_FN);

#endif /* HSI_DBG_DISABLE */
