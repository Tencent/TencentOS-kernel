/*
 * Copyright (c) 2015-2016, Broadcom. All rights reserved.  The term
 * Broadcom refers to Broadcom Limited and/or its subsidiaries.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * BSD license below:
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR 
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Author: Eddie Wai <eddie.wai@broadcom.com>
 *
 * Description: Interface header between bnxt_en and bnxt_re
 */

#ifndef __BNXT_RE_NETIF_H__
#define __BNXT_RE_NETIF_H__

#include <linux/pci.h>
#include <linux/netdevice.h>

/* RoCE ctrl */
struct bnxt_roce_ctrl_info {
	u32	cmd;
#define ROCE_CTRL_START_CMD	0x0001
#define ROCE_CTRL_STOP_CMD	0x0002
	union {
		int	dummy;
	} data;
};

/* NET ctrl */
struct bnxt_net_ctrl_drv {
	void		*rdev;
	char		version[32];
#define BNXT_RE_MSIX_VECTOR		2
#define BNXT_RE_AEQ_IDX			0
#define BNXT_RE_NQ_IDX			1
	/* [0]= AEQ, [1]= NQ */
	int		roce_irq_num[BNXT_RE_MSIX_VECTOR];
	int		roce_db_offset[BNXT_RE_MSIX_VECTOR];
	u16		ring_id_start;
	u16		ring_id_max;
};

struct bnxt_net_ctrl_ring {
	int		nr_pages;
	u32		type;
	u32		map_idx;
	u32		ring_mask;
	dma_addr_t	*dma_arr;
	u16		fw_ring_id;
};

struct bnxt_net_ctrl_stats {
	u32		update_period_ms;
	dma_addr_t	dma_map;
	u32		fw_stats_ctx_id;
};

struct bnxt_net_ctrl_info {
	u32	cmd;
#define NET_CTRL_REGISTER_CMD		0x1001
#define NET_CTRL_UNREGISTER_CMD		0x1002
#define NET_CTRL_RING_ALLOC_CMD		0x1003
#define NET_CTRL_RING_FREE_CMD		0x1004
#define NET_CTRL_STATS_CTX_ALLOC_CMD	0x1005
#define NET_CTRL_STATS_CTX_FREE_CMD	0x1006

	union {
		struct bnxt_net_ctrl_drv	drv;
		struct bnxt_net_ctrl_ring	ring;
		struct bnxt_net_ctrl_stats	stats;
	} data;
};

struct bnxt_re_dev;
/******************************************************************************
 * bnxt_re_ethdev:
 * - Owned by bnxt_re for bnxt_en to install routines to
 *****************************************************************************/
struct bnxt_net_roce_intf {
	struct pci_dev		*pdev;
	struct bnxt_re_dev	*rdev;
	u32			flags;
#define BNXT_RE_REGISTERED	(1 << 0)
#define BNXT_RE_ROCEV1_SUPPORT	(1 << 3)
#define BNXT_RE_ROCEV2_SUPPORT	(1 << 4)
#define BNXT_RE_ROCE_SUPPORT	(BNXT_RE_ROCEV1_SUPPORT |	\
				 BNXT_RE_ROCEV2_SUPPORT)
	char			version[32];
	int			roce_irq_num[BNXT_RE_MSIX_VECTOR];
	int			roce_db_offset[BNXT_RE_MSIX_VECTOR];
	u16			ring_id_start;
	u16			ring_id_max;
	u16			*ring_id_arr;

	/* For bnxt_re to call into bnxt_en */
	int			(*net_ctrl)(struct net_device *netdev,
					    struct bnxt_net_ctrl_info *info);

	/* For bnxt_en to call into bnxt_re */
	int			(*roce_ctrl)(void *data,
					     struct bnxt_roce_ctrl_info *info);
};
#endif
